==================================================================================
X-Wing Alliance Tour/Combat Engagements hook for Multiplayer by Justagai (v 1.2.1)
==================================================================================

===============================
CHANGELOG
===============================

1.2.1

- Updated Combat missions to make use of different tactical officers
- Included hook_tourmultiplayer.cfg
- Disabling xvt combat simulator background also restores original music

1.2

- Tactical Officers 3-7 can now be loaded as well as having different tactical officers between Team 1 and Team 2
- Included XvT Imperial Tactical officers
- Clients on the roster screen will now see the correct FG list
- Fixed bug where the mission list scroll bar would move to the bottom in Skirmish mode
- Added Mission Description button to UI
- Imperial Wingmen voices have been removed from my hook and are now controlled by Jeremy's wingmen voices hook
- Combat Engagements mode now has the correct UI buttons on the roster screen
- Fixed a bug where the wingmen menu would be grayed out if the player had multiple waves
- Fixed bug where Skirmish mode was loaded on the roster after exiting a Tour mission in Multiplayer

1.1

- Can disable the xvt combat simulator background in hook_tourmultiplayer.cfg
- Readme updated

1.0

- Patch is now a dll hook
- A ton of visual bugs fixed
- Allows waves/craft jumping for players for any gamemode set from mission file
- New pilots can now access Training Exercises even if they haven't completed the first campaign mission
- Removed white targeting boxes around friendlies in Skirmish 
- Changed winning team melee targeting box color from purple to dark blue
- "m" key will allow players to cycle regions if they are out of play (out of waves or pressed q and space)
- Changed color of targeting box to white
- Changed color of Camera targeting box to blueish white
- Changed IFF 4 (Imperial Traitor) color from red to orange
- Changed Player targeting box/waypoint color of IFF 4 (Imperial Traitor) to orange
- Changed Player targeting box/waypoint color of IFF 1 (Imperial) from orange to a bright red (like in XvT)
- Changed Player targeting box/waypoint color of IFF 5 (Purple) from yellow to purple
- Changed standard waypoint color from red to white
- FG names on roster are now correct (only for the host, clients currently still see the incorrect names)
- Selecting waves for a FG as host in a gamemode other than Skirmish no longer sets it to 0
- Scroll button no longer goes to the bottom of the screen when clicking on the load button
- Removed mission select arrows (they are buggy and are made obsolete with the load button anyway)
- Combat simulator now has a different background
- Music in combat simulator has been changed
- Tour button is now called "Training Exercises" button with a different look
- AI rank is no longer shown on roster unless its Skirmish
- S-foils are removed from the Assault Gunboat, Missile Boat and Skipray Blastboat (Compatible with JeremyFr's sfoils hook, sfoils will still work on those ships)
- Internet mode is now off by default when selecting/loading into a TCP/IP game
- Server update rate is now 30 by default, can be set to 8 by selecting "low" in the network settings
- Allows Imperial wingmen to talk (code from my wingmen patch is implemented with a few fixes, not compatible with JeremyFr's wingmen hook)
- Temporary fix for hangar in multiplayer (will have a better solution later)
- Fixed bug in Combat Engagement mission 2 where the autopilot takes over

===============================
WHAT IT DOES
===============================
- This patch allows you to use the built in campaign/tour mode within XWA to play the story campaign with other players, or fly custom campaigns
- also adds/fixes a ton of other improvements

===============================
FEATURES
===============================

- Allows Combat Engagements mode to be selected
- Buttons are added to access these modes and load missions
- Fixes briefing crash issue when loading multiplayer missions in singleplayer
- Adds the singleplayer XWA campaign that can be played with a total of 8 players
- Adds some Combat Engagement missions from Balance of Power
- Changes a few visuals to make it easier to pick out targets
- Compatible with XWAUP/DSUCP
- and much more

===============================
HOW TO USE
===============================
- Move all the contents to your XWA folder. Overwrite if asked.

- To load a mission, click the load button in the combat simulator and then double click on the desired mission.

- If you wish to have the original Combat Simulator background, set "xvtsimulatorbackground" to "= 0" in hook_tourmultiplayer.cfg or change it to "= 1" to turn it back on.


===============================
TACTICAL OFFICERS
===============================
- Tactical officers 3-7 can now be loaded. They must be set using a mission editor.

- The hook comes with the wave and lst files for the XvT Imperial Tactical officers. Set the Tactical officer to 3 or 4 to use them. 

- The game will look for .lst files named "tacof3, tacof4, etc" for each tac officer up to 7 respectively. So if you wish to have a custom tac officer you must name the .lst file approrpriately.

- To set the tactical officer for Team 2, either use a hex editor and change the value at offset 23B6 in the .tie file or use the YOGEME mission editor (If it does not have the option then an update should eventually come with it).


===============================
NOTES/ISSUES
===============================

Missions
--------------
- Missions with a "*" in the MISSION.LST file must have the previous mission completed before moving on in the campaign. Basically the "*" notes progression.

- Missions that are added to the MISSION.LST file without a "*" can be loaded regardless if they were completed or not.

- No longer do you need to set the mission type to Skirmish with a mission editor to have multiple waves/craft jumping. Waves/Craft jumping is allowed in all mission types. I actually recommend that you don't set it to Skirmish since it does other things to all FGs in a mission (such as adding 200% shields to fighters/shuttles by default).

- Final Death star mission does not work in multiplayer at this point.



Multiplayer
--------------
- It is recommended that all players have the hook installed. Blue bars may appear otherwise. 

- If you installed my Muliplayer exe tour patch, revert the patch, then install the hook.

- XWA installations must be almost exactly the same between players to avoid most desync errors. So if the XWAUP is installed for example then every player must have it installed with the same checkboxes the host did during the install. THIS INCLUDES THE TIE FIGHTER COCKPIT RESOLUTION! (Screen resolution can be different among players/won't cause sync issues)

- I've made a temporary "fix" for the hangar. If a player enters the hangar in multiplayer, it will just re-launch their current craft (as well as seeing a blue bar temporarily). Press q then space to exit the mission instead. Host may press Alt+Q after quitting the mission to force a mission end. Eventually I will have it where it works like in XvT (in n out with a new craft and a wave deducted).

- Players that have multiple waves and want a new craft should fly near their hanger and press "m", then target their craft and press "shift+H". Then press the "m" key again when the new craft appears.


General
--------------
- Difficulty setting does affect Combat engagements. It has the same effects like that in Tour mode. The effects are as follows:

Easy: Buffs the team with the higher player rank. Buffs AI rank by two ranks. Debuffs the team by one AI rank with lower ranked players.
I do not recommend using Easy to play combat engagements unless all players are on one team and you want it easy.

Medium: Essentially plays like "Neutral" in XvT. AI rank is whatever is set in the mission by default. 

Hard: Like the "autobalance" setting in XvT. Game will buff the AI rank of the team with the lower player rank by one. May or may not debuff team with the higher rank players.

===============================
Q & A (Troubleshooting)
===============================

Q: I'm getting a blue bar at the start of the mission in multiplayer!
A: The game is syncing all players when the mission first starts. If it continues for longer than 30 seconds, then check to make sure that your XWA installations are the same. I recommend uploading your XWA folder to the cloud (Google Drive, Onedrive, Dropbox, etc) and have other players download it if you are having trouble solving this issue.

Q: The game says I need to put in a CD when I click on Combat Engagements!
A: Make sure there is a folder called "COMBAT" is in your XWA folder with a mission.lst and missions in it.

Q: I'm on the map and out of waves but I can't see the other players!
A: You're most likely viewing a region where the other players aren't. Press the "m" key to cycle regions until you find your fellow players.

Q: I get a blue bar when I'm playing the last Death Star mission with other players!
A: The last Death Star mission is not flyable in multiplayer yet (and it may never be, so don't get your hopes up).

Q: I get a blue bar when using the hangar with other players!
A: Avoid using the hangar in multiplayer for now. Press q and then space to exit a mission instead.

Q: My game crashes when I open the Combat Simulator or when I click on Training Exercises/Combat Engagements!
A: This means the game had trouble loading the last mission flown in the pilot file. This can happen if you remove missions from the mission.lst. Make sure to always have a backup of your pilot file. You can also use a pilot editor to change the last played mission. 

Q: The game crashes when I load a custom mission in the mission list!
A: If there is a mission file missing in the MISSIONS/COMBAT folder that is listed in the mission.lst file, this could cause a crash with other missions loaded. I will fix this eventually.

Q: I'm seeing some weird stuff going on in the roster!
A: If you installed my Multiplayer exe patch before, you will have to revert it.

Q: The game says it couldn't load the dinput hook!
A: Check to see if your anti-virus is blocking it. You may have to make an exception.

Q: I have the Steam version of the game and its still saying that it can't load the dinput hook!
A: Unfortunately the current version of the dinput.dll cannot run with the Steam version. It will run with the XWAUP/DSUCP installed however.

Q: The game is saying that it couldn't hook Hook_TourMultiplayer!
A: You may have to install .NET Framework 4.6.1. It should work after that.





===============================
CONTACT
===============================

My email is justagai101@gmail.com

You may also contact me on the XWAUP forums.

For those who are looking for pilots to play mutliplayer with:

XvT/XWA Multiplayer/Pilot general hangout Discord Server (all pilots welcome) https://discord.gg/feSxXh8


===============================
CREDITS
===============================

- JeremyFr for without his work on the hooks this wouldn't have been possible
- All testers who helped test this


Have a nice flight! And may the Force be with you!

- Justagai